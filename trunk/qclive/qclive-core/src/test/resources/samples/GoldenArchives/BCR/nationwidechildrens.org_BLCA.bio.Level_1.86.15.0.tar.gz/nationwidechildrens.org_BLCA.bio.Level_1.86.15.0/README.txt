Nationwide Children�s Hospital (NCH) Biospecimen Core Resource uses the following numbering nomenclature for portion numbering in the TCGA numbering system.  This change will be effective for NCH batch 47 and moving forward.

NCH will be using the two digit portion identifier in the TCGA number to identify portions created in the BCR in the following ways:
First Digit- signifies the original portion that was created in sequential order.   
Second Digit - signifies the sub-portion created from the original portion in sequential order.

NCH processes a portion from an original tissue received (either tumor or solid normal tissue) and the slides are created from the top and bottom of that portion.  If the portion passes Pathology QC, then that portion is sectioned into 1 to 3 sub-sections (depending on size of portion) and processed in Molecular lab.  The sub-sections are then processed sequentially, and if one of the sections passes Molecular QC, the number of the sub-section is used in the TCGA number.   Example, NCH processes 2 portions initially.  The second portion passes Pathology QC.  This second portion is the cut into three sub-sections and processed individually in the Molecular lab. The first two sub-sections fail. The third sub-section passes Molecular QC and genotyping and qualifies.  The portion number for this portion is '23'.   

The sub-portions keep the top and bottom slide assignments from the original portion cut.

No other sections of the TCGA number is affected.

Reasoning: The new molecular co-isolation protocol has a higher nucleic acid yield over the previous protocol. The previous protocol required the use of three purification columns (accepting a maximum of approximately 30 mg of tissue homogenate each), so one qualified 100 mg portion was used in its entirety. To preserve as much pathology-qualified tissue as possible in its native state, NCH will initially use one third (approx 30 mg) of each portion for extractions. The second and last thirds will only be used if needed to qualify the specimen through molecular. As a full portion will not be completely consumed for most future extractions, a new portion numbering scheme is needed until a UUID numbering scheme is in place.

Originally, the portion size was between 100 and 120 mg and no subportions were tracked as separate samples.  The portion section of the TCGA number was sequentially numbered.  It started with '01' and moved forward up to '99'.  It was also inferred that portions were made in that order, for example, portion code '05' was made after portion code '01'.