# $Id: telem.pm 7166 2010-06-07 15:35:21Z jensenma $
package RepGen::telem;

=NAME

RepGen::telem - repgen.pl configuration for telemetry reports

=SYNOPSIS

Autoincluded  in repgen.pl when specified at command line:
 
 perl repgen.pl --module telem ...
  
This exports all globals as described below to the script.

=DESCRIPTION

Describe the filetype fields and report field order here.

=cut

use strict;
use warnings;
use lib '..';
use base qw(Exporter RepGen::Configure);


our @EXPORT = qw( %config %filters %fields @db_fields
                  @output_fields
                  $default_dsn $default_user $default_pwd
                  $TOO_MANY);
our (%config, %filters, %fields, @db_fields, @output_fields,
     $default_dsn, $default_user, $default_pwd,
     $TOO_MANY, $VERSION);

# defaults from base class
$VERSION = $RepGen::Configure::VERSION;
$default_dsn = $RepGen::Configure::default_dsn;
$default_user = $RepGen::Configure::default_user;
$default_pwd = $RepGen::Configure::default_pwd;
$TOO_MANY = $RepGen::Configure::TOO_MANY;

%filters = (
    sample => sub { $_ ? m/\tTCGA-/ : 0 },
    exchange => sub { $_ ? m/TCGA-/ : 0 }
    );
%fields = (
    sample => [qw( RecDate PubDate AliquotBC PatientBC SampleBC GSCID )],
    exchange => [qw(RecDate PubDate AliquotBC PatientBC SampleBC GSCID)]
    );

@db_fields = qw(TumAbbrev GSC);

@output_fields = qw( RecDate PubDate AliquotBC PatientBC SampleBC TumAbbrev GSC );

# set parse parameters for  fields:

# sample accessions file:
@config{map { "sample.".$_ } @{$fields{sample}}} = 
    (
     { 
	 header => "Received Date",
	 regexp => qr/^(\d\d\d\d\-\d\d\-\d\d)T/,
	 token => 5,
	 match_posn => 1
     },
     {
	 header => "Published Date", 
	 regexp => qr/^(\d\d\d\d\-\d\d\-\d\d)T/,
	 token => 4,
	 match_posn => 1
     },
     {
	 header => 'Aliquot Barcode',
	 token => 9
     },
     {
	 header => 'Patient Barcode',
	 regexp => qr/^((TCGA-\d\d-\d\d\d\d)-\d\d).*(\d\d)$/,
	 token => 9,
	 match_posn => 2
     },
     { 
	 header => 'Sample Barcode',
	 regexp => qr/^((TCGA-\d\d-\d\d\d\d)-\d\d).*(\d\d)$/,
	 token => 9,
	 match_posn => 1
     },
     { 
	 header => 'GSCID',
	 regexp => qr/^((TCGA-\d\d-\d\d\d\d)-\d\d).*(\d\d)$/,
	 token => 9, 
	 match_posn => 3
     }
    );
# exchange.tab file
@config{map { "exchange.".$_ } @{$fields{exchange}}} = 
  (
   { 
    header => "Received Date",
    token => 4
   },
   {
    header => "Published Date", 
    constant => "BAM (no published date)"
   },
   {
    header => 'Aliquot Barcode',
    regexp =>  qr/^(TCGA-[0-9a-z-]+)/i, 
    token => 2,
    match_posn => 1
   },
   {
    header => 'Patient Barcode',
    regexp => qr/(((TCGA-\w\w-\w\w\w\w)-\w\w)[A-Z0-9\-]+)[_\.].+/,
    token => 2,
    match_posn => 2
   },
   { 
    header => 'Sample Barcode',
    regexp => qr/(((TCGA-\w\w-\w\w\w\w)-\w\w)[A-Z0-9\-]+)[_\.].+/,
    token => 2,
    match_posn => 3
   },
   { 
    header => 'GSCID',
    regexp => qr/TCGA(?:-[0-9a-z]+)+-([0-9]+)/i,
    token => 2,
    match_posn => 1
   }
  );

# set up parameters for the looked-up fields
@config{@db_fields} =
    (
     {
	 header => 'Disease',
	 sql => 
	     "SELECT DISTINCT ti.tumor_abbreviation ".
	     "FROM biospecimen_barcode bb,".
	     " biospecimen_to_tumor btt,tumor_info ti ".
	     "WHERE bb.barcode=? AND ".
	     " bb.biospecimen_id=btt.biospecimen_id AND ".
	     " btt.tumor_id=ti.id",
	 lookup_fld => 'AliquotBC'
     },
     {
	 header => 'GSC',
	 sql => "SELECT short_name FROM center_info WHERE id = ?",
	 lookup_fld => 'GSCID'
     }

    );

1;
